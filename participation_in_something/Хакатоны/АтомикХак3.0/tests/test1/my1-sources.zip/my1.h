#ifndef MY1_H
#define MY1_H

extern double controldtt;

extern void my1_step();
extern void my1_initialization();

#include "math.h"
#include "stdlib.h"

#endif